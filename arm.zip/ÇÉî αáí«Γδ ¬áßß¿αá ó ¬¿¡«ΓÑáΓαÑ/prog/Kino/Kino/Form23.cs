﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kino
{
    public partial class Form23 : Form
    {
        public Form23()
        {
            InitializeComponent();
        }
        string Connection = System.Configuration.ConfigurationManager.ConnectionStrings["Kino.Properties.Settings.kinoConnectionString"].ConnectionString;

        private void Form23_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select COUNT(Код) as count , SUM(Цена) as Цена, Фильм from Билет where Код in (select Код from Билет where " + String.Format("Дата_время >= '{0:yyyy-MM-dd}' AND Дата_время < '{1:yyyy-MM-dd}'", dateTimePicker1.Value.ToShortDateString(), dateTimePicker2.Value.AddDays(1).ToShortDateString())+") group by Фильм" ;
            this.chart1.Series["Продажи"].Points.Clear();
            using (SqlConnection c = new SqlConnection(Connection))
            {
                c.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(sql, c))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    biletyDataGridView.DataSource = t;
                    if (biletyDataGridView.RowCount > 0)
                        for (int i = 0; i < biletyDataGridView.RowCount; i++)
                        {
                            this.chart1.Series["Продажи"].Points.AddXY(biletyDataGridView.Rows[i].Cells["Фильм"].Value.ToString(), biletyDataGridView.Rows[i].Cells["Количество"].Value.ToString());
                        }
                }
            }
        }

        private void biletyDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
