﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kino
{
    public partial class Form24 : Form
    {
        public Form24()
        {
            InitializeComponent();
        }

        private void билетBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.билетBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kinoDataSet);

        }
        string Connection = System.Configuration.ConfigurationManager.ConnectionStrings["Kino.Properties.Settings.kinoConnectionString"].ConnectionString;

        private void Form24_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kinoDataSet.Зал". При необходимости она может быть перемещена или удалена.
            this.залTableAdapter.Fill(this.kinoDataSet.Зал);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kinoDataSet.Билет". При необходимости она может быть перемещена или удалена.
            this.билетTableAdapter.Fill(this.kinoDataSet.Билет);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "SELECT SUM(Цена) AS Цена, Дата_время, Фильм FROM Билет GROUP BY Сеанс, Дата_время, Фильм having " + String.Format("Дата_время >= '{0:yyyy-MM-dd}' AND Дата_время < '{1:yyyy-MM-dd}'", dateTimePicker1.Value.ToShortDateString(), dateTimePicker2.Value.AddDays(1).ToShortDateString()) + "";
            this.chart1.Series["Продажи"].Points.Clear();
            using (SqlConnection c = new SqlConnection(Connection))
            {
                c.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(sql, c))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    билетDataGridView.DataSource = t;
                    if (билетDataGridView.RowCount > 0)
                    {
                        int sum = 0;
                        for (int i = 0; i < билетDataGridView.RowCount; i++)
                        {
                            sum += Convert.ToInt32(билетDataGridView.Rows[i].Cells["Column1"].Value.ToString());
                            this.chart1.Series["Продажи"].Points.AddXY(билетDataGridView.Rows[i].Cells["Column2"].Value.ToString(), билетDataGridView.Rows[i].Cells["Column1"].Value.ToString());
                        }
                        label5.Text = sum.ToString();
                    }
                }
            }
        }
    }
}
