﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kino
{
    public partial class Form26 : Form
    {
        public Form26()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form13 x = new Form13();
            x.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form17 x = new Form17();
            x.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form19 x = new Form19();
            x.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
