﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kino
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kinoDataSet.Пользователь". При необходимости она может быть перемещена или удалена.
            this.пользовательTableAdapter.Fill(this.kinoDataSet.Пользователь);
        }

        private void button2_Click(object sender, EventArgs e)
        {
          if (textBox1.Text != "")
            {
                if (textBox1.Text == ((DataRowView)пользовательBindingSource.Current).Row["Пароль"].ToString())
                {
                    if (comboBox1.Text == "Администратор")
                    {
                        Form2 x = new Form2();
                        x.ShowDialog();
                    }
                    else 
                    {
                        Form26 x = new Form26();
                        x.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Пароль неверный");
                }
            }
            else
            {
                MessageBox.Show("Введите пароль");
            } 
        }
    }
}
