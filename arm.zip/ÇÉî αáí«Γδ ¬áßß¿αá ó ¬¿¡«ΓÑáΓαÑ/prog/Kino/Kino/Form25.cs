﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kino
{
    public partial class Form25 : Form
    {
        public Form25()
        {
            InitializeComponent();
        }
        string Connection = System.Configuration.ConfigurationManager.ConnectionStrings["Kino.Properties.Settings.kinoConnectionString"].ConnectionString;

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select COUNT(Код) as count , SUM(Цена) as Цена, Номер_зала, Зал.Название from Билет inner join Зал on Билет.Номер_зала = Зал.Номер where Код in (select Код from Билет  where  " + String.Format("Дата_время >= '{0:yyyy-MM-dd}' AND Дата_время < '{1:yyyy-MM-dd}'", dateTimePicker1.Value.ToShortDateString(), dateTimePicker2.Value.AddDays(1).ToShortDateString())+")  group by Номер_зала, Зал.Название";
            this.chart1.Series["Продажи"].Points.Clear();
            this.chart2.Series["Продажи"].Points.Clear();
            using (SqlConnection c = new SqlConnection(Connection))
            {
                c.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(sql, c))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    biletyDataGridView.DataSource = t;
                    if (biletyDataGridView.RowCount > 0)
                        for (int i = 0; i < biletyDataGridView.RowCount; i++)
                        {
                            this.chart1.Series["Продажи"].Points.AddXY(biletyDataGridView.Rows[i].Cells["Зал"].Value.ToString(), biletyDataGridView.Rows[i].Cells["Количество"].Value.ToString());
                            this.chart2.Series["Продажи"].Points.AddXY(biletyDataGridView.Rows[i].Cells["Зал"].Value.ToString(), biletyDataGridView.Rows[i].Cells["Цена"].Value.ToString());
                        }
                }
            }
        }
    }
}
