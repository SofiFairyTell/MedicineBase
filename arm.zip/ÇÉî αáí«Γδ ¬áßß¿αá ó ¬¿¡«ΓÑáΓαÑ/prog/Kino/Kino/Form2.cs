﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kino
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 x = new Form3();
            x.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 x = new Form6();
            x.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8 x = new Form8();
            x.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form11 x = new Form11();
            x.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form13 x = new Form13();
            x.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form17 x = new Form17();
            x.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form19 x = new Form19();
            x.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form21 x = new Form21();
            x.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("help\\1.chm");
        }
    }
}
