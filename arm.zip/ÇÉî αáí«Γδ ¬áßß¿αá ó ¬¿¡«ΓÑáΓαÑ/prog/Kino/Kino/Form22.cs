﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kino
{
    public partial class Form22 : Form
    {
        public Form22()
        {
            InitializeComponent();
        }
        string Connection = System.Configuration.ConfigurationManager.ConnectionStrings["Kino.Properties.Settings.kinoConnectionString"].ConnectionString;

        private void Form22_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select COUNT(Код) as count , SUM(Цена) as Цена, Фильм, Дата_время from Билет group by Сеанс, Фильм, Дата_время  having " + String.Format("Дата_время >= '{0:yyyy-MM-dd}' AND Дата_время < '{1:yyyy-MM-dd}'", dateTimePicker1.Value.ToShortDateString(), dateTimePicker2.Value.AddDays(1).ToShortDateString()) + " order by Дата_время asc";
                this.chart1.Series["Продажи"].Points.Clear();
            using (SqlConnection c = new SqlConnection(Connection))
            {
                c.Open();
                using (SqlDataAdapter a = new SqlDataAdapter(sql, c))
                {
                    DataTable t = new DataTable();
                    a.Fill(t);
                    biletyDataGridView.DataSource = t;
                     if (biletyDataGridView.RowCount > 0)
                for (int i = 0; i < biletyDataGridView.RowCount; i++)
                {
                    this.chart1.Series["Продажи"].Points.AddXY(biletyDataGridView.Rows[i].Cells["Дата_время"].Value.ToString() + ", " + biletyDataGridView.Rows[i].Cells["Сеанс"].Value.ToString() , biletyDataGridView.Rows[i].Cells["Количество"].Value.ToString());
                }
                }
            }
        }
    }
}
