﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kino
{
    public partial class Form21 : Form
    {
        public Form21()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form22 x = new Form22();
            x.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form23 x = new Form23();
            x.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form24 x = new Form24();
            x.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form25 x = new Form25();
            x.ShowDialog();
        }
    }
}
