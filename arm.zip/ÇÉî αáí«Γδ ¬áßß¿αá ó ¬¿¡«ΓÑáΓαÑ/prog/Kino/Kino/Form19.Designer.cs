﻿namespace Kino
{
    partial class Form19
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kinoDataSet = new Kino.kinoDataSet();
            this.броньBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.броньTableAdapter = new Kino.kinoDataSetTableAdapters.БроньTableAdapter();
            this.tableAdapterManager = new Kino.kinoDataSetTableAdapters.TableAdapterManager();
            this.билетTableAdapter = new Kino.kinoDataSetTableAdapters.БилетTableAdapter();
            this.броньDataGridView = new System.Windows.Forms.DataGridView();
            this.билетBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Билет = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Код_билета = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Билет2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Билет3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Билет4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Билет5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.kinoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.билетBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // kinoDataSet
            // 
            this.kinoDataSet.DataSetName = "kinoDataSet";
            this.kinoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // броньBindingSource
            // 
            this.броньBindingSource.DataMember = "Бронь";
            this.броньBindingSource.DataSource = this.kinoDataSet;
            // 
            // броньTableAdapter
            // 
            this.броньTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Kino.kinoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.БилетTableAdapter = this.билетTableAdapter;
            this.tableAdapterManager.БроньTableAdapter = this.броньTableAdapter;
            this.tableAdapterManager.ЗалTableAdapter = null;
            this.tableAdapterManager.ПерсоналTableAdapter = null;
            this.tableAdapterManager.ПользовательTableAdapter = null;
            this.tableAdapterManager.СеансTableAdapter = null;
            this.tableAdapterManager.ФильмTableAdapter = null;
            // 
            // билетTableAdapter
            // 
            this.билетTableAdapter.ClearBeforeFill = true;
            // 
            // броньDataGridView
            // 
            this.броньDataGridView.AllowUserToAddRows = false;
            this.броньDataGridView.AutoGenerateColumns = false;
            this.броньDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.броньDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Билет,
            this.Код_билета,
            this.dataGridViewTextBoxColumn2,
            this.Билет2,
            this.Билет3,
            this.Билет4,
            this.Билет5,
            this.dataGridViewTextBoxColumn3});
            this.броньDataGridView.DataSource = this.броньBindingSource;
            this.броньDataGridView.Location = new System.Drawing.Point(12, 12);
            this.броньDataGridView.Name = "броньDataGridView";
            this.броньDataGridView.ReadOnly = true;
            this.броньDataGridView.RowHeadersVisible = false;
            this.броньDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.броньDataGridView.Size = new System.Drawing.Size(666, 242);
            this.броньDataGridView.TabIndex = 1;
            this.броньDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.броньDataGridView_CellContentClick);
            // 
            // билетBindingSource
            // 
            this.билетBindingSource.DataMember = "Билет";
            this.билетBindingSource.DataSource = this.kinoDataSet;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 260);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(323, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "Продать забронированный билет";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(355, 260);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(323, 30);
            this.button2.TabIndex = 2;
            this.button2.Text = "Удалить билет и бронь";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // Билет
            // 
            this.Билет.DataPropertyName = "Билет";
            this.Билет.HeaderText = "Билет";
            this.Билет.Name = "Билет";
            this.Билет.ReadOnly = true;
            this.Билет.Visible = false;
            // 
            // Код_билета
            // 
            this.Код_билета.DataPropertyName = "Билет";
            this.Код_билета.DataSource = this.билетBindingSource;
            this.Код_билета.DisplayMember = "Сеанс";
            this.Код_билета.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Код_билета.HeaderText = "Код_билета";
            this.Код_билета.Name = "Код_билета";
            this.Код_билета.ReadOnly = true;
            this.Код_билета.ValueMember = "Код";
            this.Код_билета.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Билет";
            this.dataGridViewTextBoxColumn2.DataSource = this.билетBindingSource;
            this.dataGridViewTextBoxColumn2.DisplayMember = "Дата_время";
            this.dataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата и время";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn2.ValueMember = "Код";
            // 
            // Билет2
            // 
            this.Билет2.DataPropertyName = "Билет";
            this.Билет2.DataSource = this.билетBindingSource;
            this.Билет2.DisplayMember = "Фильм";
            this.Билет2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Билет2.HeaderText = "Фильм";
            this.Билет2.Name = "Билет2";
            this.Билет2.ReadOnly = true;
            this.Билет2.ValueMember = "Код";
            // 
            // Билет3
            // 
            this.Билет3.DataPropertyName = "Билет";
            this.Билет3.DataSource = this.билетBindingSource;
            this.Билет3.DisplayMember = "Номер_зала";
            this.Билет3.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Билет3.HeaderText = "Номер зала";
            this.Билет3.Name = "Билет3";
            this.Билет3.ReadOnly = true;
            this.Билет3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Билет3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Билет3.ValueMember = "Код";
            // 
            // Билет4
            // 
            this.Билет4.DataPropertyName = "Билет";
            this.Билет4.DataSource = this.билетBindingSource;
            this.Билет4.DisplayMember = "Ряд";
            this.Билет4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Билет4.HeaderText = "Ряд";
            this.Билет4.Name = "Билет4";
            this.Билет4.ReadOnly = true;
            this.Билет4.ValueMember = "Код";
            // 
            // Билет5
            // 
            this.Билет5.DataPropertyName = "Билет";
            this.Билет5.DataSource = this.билетBindingSource;
            this.Билет5.DisplayMember = "Место";
            this.Билет5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.Билет5.HeaderText = "Место";
            this.Билет5.Name = "Билет5";
            this.Билет5.ReadOnly = true;
            this.Билет5.ValueMember = "Код";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn3.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // Form19
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(690, 302);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.броньDataGridView);
            this.Name = "Form19";
            this.Text = "Забронированные билеты";
            this.Load += new System.EventHandler(this.Form19_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kinoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.билетBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private kinoDataSet kinoDataSet;
        private System.Windows.Forms.BindingSource броньBindingSource;
        private kinoDataSetTableAdapters.БроньTableAdapter броньTableAdapter;
        private kinoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView броньDataGridView;
        private kinoDataSetTableAdapters.БилетTableAdapter билетTableAdapter;
        private System.Windows.Forms.BindingSource билетBindingSource;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Билет;
        private System.Windows.Forms.DataGridViewComboBoxColumn Код_билета;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn Билет2;
        private System.Windows.Forms.DataGridViewComboBoxColumn Билет3;
        private System.Windows.Forms.DataGridViewComboBoxColumn Билет4;
        private System.Windows.Forms.DataGridViewComboBoxColumn Билет5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    }
}