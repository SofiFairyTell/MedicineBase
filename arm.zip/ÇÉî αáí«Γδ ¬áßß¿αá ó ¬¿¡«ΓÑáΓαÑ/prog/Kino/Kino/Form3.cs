﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kino
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void фильмBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.фильмBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kinoDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kinoDataSet.Фильм". При необходимости она может быть перемещена или удалена.
            this.фильмTableAdapter.Fill(this.kinoDataSet.Фильм);
            if (фильмDataGridView.Rows.Count > 0)
            {
                textBox1.Text = фильмDataGridView.CurrentRow.Cells["dataGridViewTextBoxColumn6"].Value.ToString();
                textBox2.Text = фильмDataGridView.CurrentRow.Cells["dataGridViewTextBoxColumn7"].Value.ToString();
            }
            numericUpDown5.Visible = false;
            numericUpDown6.Visible = false;
            label9.Visible = false;
            label8.Visible = false;
            numericUpDown3.Visible = false;
            numericUpDown4.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            label5.Visible = false;
            label4.Visible = false;
            textBox4.Visible = false;
            textBox3.Visible = false; 
        }

        private void фильмDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = фильмDataGridView.CurrentRow.Cells["dataGridViewTextBoxColumn6"].Value.ToString();
            textBox2.Text = фильмDataGridView.CurrentRow.Cells["dataGridViewTextBoxColumn7"].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 x = new Form4();
            x.ShowDialog();
            this.фильмTableAdapter.Fill(this.kinoDataSet.Фильм);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                if (radioButton1.Checked)
                    фильмDataGridView.Sort(dataGridViewTextBoxColumn2, System.ComponentModel.ListSortDirection.Ascending);
                else if (radioButton2.Checked)
                    фильмDataGridView.Sort(dataGridViewTextBoxColumn2, System.ComponentModel.ListSortDirection.Descending);
            }
            else
                if (comboBox1.SelectedIndex == 1)
                {
                    if (radioButton1.Checked)
                        фильмDataGridView.Sort(dataGridViewTextBoxColumn3, System.ComponentModel.ListSortDirection.Ascending);
                    else if (radioButton2.Checked)
                        фильмDataGridView.Sort(dataGridViewTextBoxColumn3, System.ComponentModel.ListSortDirection.Descending);
                }
                else
                    if (comboBox1.SelectedIndex == 2)
                    {
                        if (radioButton1.Checked)
                            фильмDataGridView.Sort(dataGridViewTextBoxColumn4, System.ComponentModel.ListSortDirection.Ascending);
                        else if (radioButton2.Checked)
                            фильмDataGridView.Sort(dataGridViewTextBoxColumn4, System.ComponentModel.ListSortDirection.Descending);
                    }
                    else
                        if (comboBox1.SelectedIndex == 3)
                        {
                            if (radioButton1.Checked)
                                фильмDataGridView.Sort(dataGridViewTextBoxColumn5, System.ComponentModel.ListSortDirection.Ascending);
                            else if (radioButton2.Checked)
                                фильмDataGridView.Sort(dataGridViewTextBoxColumn5, System.ComponentModel.ListSortDirection.Descending);
                        }
                        else

                            if (comboBox1.SelectedIndex == 4)
                            {
                                if (radioButton1.Checked)
                                    фильмDataGridView.Sort(dataGridViewTextBoxColumn8, System.ComponentModel.ListSortDirection.Ascending);
                                else if (radioButton2.Checked)
                                    фильмDataGridView.Sort(dataGridViewTextBoxColumn8, System.ComponentModel.ListSortDirection.Descending);
                            }
                            else
                        MessageBox.Show("Выберите критерий сортировки!");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                label5.Visible = true;
                label4.Visible = true;
            }
            else
            {
                numericUpDown1.Visible = false;
                numericUpDown2.Visible = false;
                label5.Visible = false;
                label4.Visible = false;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.фильмBindingSource.Filter = ""; //сбрасываем 
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox3.Visible = true;
                textBox3.Text = String.Empty;
            }
            else
                textBox3.Visible = false;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                textBox4.Visible = true;
                textBox4.Text = String.Empty;
            }
            else
                textBox4.Visible = false;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                numericUpDown3.Visible = true;
                numericUpDown4.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
            }
            else
            {
                numericUpDown3.Visible = false;
                numericUpDown4.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                numericUpDown5.Visible = true;
                numericUpDown6.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
            }
            else
            {
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                label9.Visible = false;
                label8.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string filter = "Код = Код "; //задаем строку для поиска
            bool error = false;
            if (checkBox1.Checked || checkBox2.Checked || checkBox3.Checked || checkBox4.Checked || checkBox5.Checked) // если хотя бы один вид выбрано
            {
                if (checkBox1.Checked)
                {
                    if (textBox3.Text != "")
                    {
                        filter += " and Название like '%" + textBox3.Text + "%' ";
                    }
                    else
                    {
                        error = true;
                    }
                }
                if (checkBox3.Checked)
                {
                    if (textBox4.Text != "")
                    {
                        filter += " and Жанр like '%" + textBox4.Text + "%' ";
                    }
                    else
                    {
                        error = true;
                    }
                }
                if (checkBox2.Checked)
                {
                    filter += " and Продолжительность >= " + numericUpDown1.Value + " and Продолжительность <=  " + numericUpDown2.Value + " ";
                }

                if (checkBox4.Checked)
                {
                    filter += " and Рейтинг >= " + numericUpDown3.Value + " and Рейтинг <=  " + numericUpDown4.Value + " ";
                }

                if (checkBox5.Checked)
                {
                    filter += " and Год >= " + numericUpDown5.Value + " and Год <=  " + numericUpDown6.Value + " ";
                }

                if (error)
                {
                    MessageBox.Show("Заполните поле поиска для выбранного критерия!");
                    return;
                }
                else
                {
                    this.фильмBindingSource.Filter = filter; //фильтрация
                }

            }
            else
                MessageBox.Show("Выберите хотя бы один критерий поиска!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 x = new Form5();
            x.ShowDialog();
            this.фильмTableAdapter.Fill(this.kinoDataSet.Фильм);
        }

    }
}
